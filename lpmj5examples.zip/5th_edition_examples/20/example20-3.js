function C(i)
{
  return document.getElementsByClassname(i)
} 
