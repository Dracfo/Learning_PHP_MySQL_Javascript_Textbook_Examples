<?php // login.php
  $hn = 'localhost';
  $db = 'publications';
  $un = 'username'; // Change this
  $pw = 'password'; // Change this
?>
