<?php // login.php
      // Change these details to suit your installation
  $hn = 'localhost';
  $db = 'publications';
  $un = 'root';
  $pw = 'mysql';
?>
