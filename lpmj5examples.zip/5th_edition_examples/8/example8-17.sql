SELECT COUNT(*) FROM classics;
