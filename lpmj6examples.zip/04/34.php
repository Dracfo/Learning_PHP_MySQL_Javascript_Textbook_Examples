<?php
  for ($count = 1 ; $count <= 12 ; ++$count)
  {
	echo "$count times 12 is " . $count * 12;
	echo "<br>";
  }
?>
