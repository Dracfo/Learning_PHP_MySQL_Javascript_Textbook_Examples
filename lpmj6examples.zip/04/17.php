<?php
  if ($finished == 1 or getnext() == 1) exit;
?>
