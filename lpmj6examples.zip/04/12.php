<?php
  $month = "March";

  if ($month == "March") echo "It's springtime";
?>
